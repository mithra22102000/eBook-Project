package com.example.eBookStore_Consumer_eureka_feign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumerEurekaFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
