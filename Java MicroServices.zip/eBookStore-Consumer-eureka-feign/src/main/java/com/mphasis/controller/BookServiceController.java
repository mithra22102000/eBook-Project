package com.mphasis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.entity.Book;
import com.mphasis.proxy.BookServiceProxy;

@RestController
@Scope("request")
public class BookServiceController {

	@Autowired(required=true)
	private BookServiceProxy serviceProxy;
	
	@GetMapping("/get-books/{id}")
	public Book getBookById(@PathVariable Long id) {
		return serviceProxy.getBookById(id);
		
	}
	
	@GetMapping("/get-books")
	public List<Book> getAllBooks(){
		return serviceProxy.getAllBooks();
		
	}
	
}
