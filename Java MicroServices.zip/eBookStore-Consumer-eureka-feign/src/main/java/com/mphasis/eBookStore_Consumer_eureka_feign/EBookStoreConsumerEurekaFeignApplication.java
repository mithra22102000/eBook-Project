package com.mphasis.eBookStore_Consumer_eureka_feign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;


@EnableFeignClients(basePackages = "com.mphasis.proxy")
@SpringBootApplication
@ComponentScan("com.mphasis.controller")
@EntityScan("com.mphasis.entity")
public class EBookStoreConsumerEurekaFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumerEurekaFeignApplication.class, args);
	}

}
