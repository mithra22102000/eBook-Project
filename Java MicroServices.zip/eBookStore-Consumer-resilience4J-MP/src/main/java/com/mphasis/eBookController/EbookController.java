package com.mphasis.eBookController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.entity.Book;
import com.mphasis.service.BookService;
 
import io.micrometer.core.annotation.Timed;
 
@RestController
@Scope("request")
public class EbookController {
 
	@Autowired
	@Qualifier("bookService")
	private BookService bookService;
	
	@Timed(value="getBookById.time" , description = "Time taken to return book")
	 @GetMapping("/getbooks/{id}")
	    public Book getBookById(@PathVariable Long id) {
	        return bookService.getBookById(id);
	    }
}