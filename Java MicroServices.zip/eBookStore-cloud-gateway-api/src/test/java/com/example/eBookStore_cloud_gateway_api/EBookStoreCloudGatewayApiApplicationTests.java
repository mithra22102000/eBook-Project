package com.example.eBookStore_cloud_gateway_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreCloudGatewayApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
