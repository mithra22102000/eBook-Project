package com.example.fallback;
 
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.entity.Book;
import com.example.proxy.BookServiceProxy;
 
@Service
public class BookServiceFallback  implements BookServiceProxy{
 
	@Override
	public Book getBookById(Long id) {
		return new Book(id, "JavaProgramming","Dennies Ritche","978-09-86-3245", 1526, 2000, "Ranne mon");
	}
 
	@Override
	public List<Book> getAllBooks() {
		return Arrays.asList();
	}
 
}