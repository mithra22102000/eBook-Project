package com.mphasis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.entity.Employee;
import com.mphasis.producer.EmployeeRegistrationProducer;

@RestController
public class EmployeeRegistrationController {
	
	@Autowired
    private EmployeeRegistrationProducer employeeRegisterProducer;
     
	@PostMapping(value="register")
	public String orderFood(@RequestBody Employee employee) {
		employeeRegisterProducer.sendMessage(employee);
		return "Message was send successfully";
	}

}
