package com.mphasis.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.mphasis.entity.Book;
import com.mphasis.repository.BookStoreRepository;

@Service(value="ebookService")
@Scope("singleton")
public class ebookstoreService implements ebookService{

	@Autowired
	@Qualifier(value="bookRepository")
	private BookStoreRepository bookRepository;

	@Override
	public Book addBook(Book book) {
		
		return bookRepository.save(book);
	}

	@Override
	public Book updateBook(Book book) {
		
		return bookRepository.save(book);
	}

	@Override
	public List<Book> findAllBooks() {
		
		return bookRepository.findAll();
	}

	@Override
	public Book findByBookId(Long id) {
		
		return bookRepository.findById(id).get();
	}

	@Override
	public void deleteBook(Long id) {
		bookRepository.deleteById(id);
	}

	@Override
	public List<Book> findByBookTitle(String title) {
		
		return bookRepository.findByTitle(title);
	}

	@Override
	public List<Book> findByBookPublisher(String publisher) {
		
		return bookRepository.findByPublisher(publisher);
	}

	@Override
	public List<Book> findByBookYear(int year) {
		
		return bookRepository.findByYear(year);
	}
}
