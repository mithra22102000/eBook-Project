package com.example.service;

import java.util.List;

import com.example.entity.Book;

public interface ebookService {

	public Book addBook(Book book);
	public Book updateBook(Book book);
	public List<Book> findAllBooks();
	public Book findByBookId(Long id);
	public void deleteBook(Long id);
	
	public List<Book> findByBookTitle(String title);
	public List<Book> findByBookPublisher(String publisher);
	public List<Book> findByBookYear(int year);
}
