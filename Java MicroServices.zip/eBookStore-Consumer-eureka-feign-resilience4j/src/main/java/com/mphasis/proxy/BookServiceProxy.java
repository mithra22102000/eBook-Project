package com.mphasis.proxy;
 
import java.util.Arrays;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mphasis.entity.Book;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
 
@FeignClient(name= "book-service")
public interface BookServiceProxy {

	@Retry(name="book-service")
	@CircuitBreaker(name="book-service",fallbackMethod = "fallbackgetBookById")
	@GetMapping(value="/books/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public Book getBookById(@PathVariable Long id);

	@Retry(name="book-service")
	@CircuitBreaker(name="book-service",fallbackMethod = "fallbackgetAllBooks")
	@GetMapping(value="/books", produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Book> getAllBooks();


	default Book fallbackgetBookById(Long id,Throwable cause) {
		System.out.println("Exception raised with:------>  "+cause.getMessage());
		return new Book(id, "JavaProgramming","Dennies Ritche","978-09-86-3245", 1526, 2000, "Ranne mon");
	}
 
	
	default List<Book> fallbackgetAllBooks(Throwable cause) {
		System.out.println("Exception raised with:------>  "+cause.getMessage());
		return Arrays.asList();
	}
 
 
}