package com.example.eBookStore_Consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;

import brave.sampler.Sampler;


@SpringBootApplication
@EnableCircuitBreaker
@ComponentScans({@ComponentScan("com.example.config"),@ComponentScan("com.example.eBookController"),@ComponentScan("com.example.service")})
@EntityScan("com.example.entity")
public class EBookStoreConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumerApplication.class, args);
	}

	public Sampler alwaysSampler() {
		return Sampler.ALWAYS_SAMPLE;
		
	}
}
