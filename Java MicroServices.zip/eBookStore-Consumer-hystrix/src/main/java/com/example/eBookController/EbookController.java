package com.example.eBookController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


import com.example.entity.Book;
import com.example.service.BookService;

@RestController
@Scope("request")
public class EbookController {

	@Autowired
	@Qualifier(value="bookService")
	private  BookService bookBervice;
	
	@GetMapping("/get-books/{id}")
	public Book getBookdById(@PathVariable Long id) {
		
		return bookBervice.getBookdById(id);
		
	}
	
}
