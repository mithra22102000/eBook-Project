package com.mphasis.eBookStore_proxy_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreProxyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
