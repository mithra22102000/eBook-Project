package com.example.eBookStore_proxy_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

import com.example.filter.ErrorFilter;
import com.example.filter.PostFilter;
import com.example.filter.PreFilter;
import com.example.filter.RouteFilter;

@SpringBootApplication
@EnableZuulProxy
public class EBookStoreProxyApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreProxyApiApplication.class, args);
	}
	
	@Bean
	PreFilter getPreFilter() {
		return new PreFilter();
		
	}
	
	@Bean
	PostFilter getPostFilter() {
		return new PostFilter();
		
	}
	@Bean
	RouteFilter getRouteFilter() {
		return new RouteFilter();
		
	}
	
	@Bean
     ErrorFilter getErrorFilter() {
		return new ErrorFilter();
		
	}
	

}
