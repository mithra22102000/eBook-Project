package com.mphasis.eBookStore_proxy_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

import com.mphasis.filter.ErrorFilter;
import com.mphasis.filter.PostFilter;
import com.mphasis.filter.PreFilter;
import com.mphasis.filter.RouteFilter;

@SpringBootApplication
@EnableZuulProxy
public class EBookStoreProxyApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreProxyApiApplication.class, args);
	}
	
	@Bean
	PreFilter getPreFilter() {
		return new PreFilter();
		
	}
	
	@Bean
	PostFilter getPostFilter() {
		return new PostFilter();
		
	}
	@Bean
	RouteFilter getRouteFilter() {
		return new RouteFilter();
		
	}
	
	@Bean
     ErrorFilter getErrorFilter() {
		return new ErrorFilter();
		
	}
	

}
