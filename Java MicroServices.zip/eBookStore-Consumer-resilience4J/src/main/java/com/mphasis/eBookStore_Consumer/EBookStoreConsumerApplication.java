package com.mphasis.eBookStore_Consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;


@SpringBootApplication
@ComponentScans({@ComponentScan("com.mphasis.config"),@ComponentScan("com.mphasis.eBookController"),@ComponentScan("com.mphasis.service")})
@EntityScan("com.mphasis.entity")
public class EBookStoreConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumerApplication.class, args);
	}

}
